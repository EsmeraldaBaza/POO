﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bidimensional3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int i, j;
        string acumuladorArray;
        int[,] arrayBidimensional = new int[100, 100];

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            MessageBox.Show(acumuladorArray, "Elementos del arreglo", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtFilas.Text = "";
            txtColumnas.Text = "";
            acumuladorArray = "";
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            int filas, columnas;
            filas = Convert.ToInt16(txtFilas.Text);
            columnas = Convert.ToInt16(txtColumnas.Text);

            int[,] arrayBidi = new int[10, 10];

            for (i = 0; i < filas; i++)
            {
                acumuladorArray += "\n";
                for (j = 0; j < columnas; j++)
                {
                    arrayBidi[i, j] = Convert.ToInt16(Interaction.InputBox("Ingrese el valor" + i + "," + j));
                    acumuladorArray += arrayBidi[i, j] + ",";
                }
            }
        }
    }
}
