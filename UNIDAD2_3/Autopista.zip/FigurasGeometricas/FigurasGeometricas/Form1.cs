﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FigurasGeometricas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void btnCuadrado_Click(object sender, EventArgs e)
        {
            
            Cuadrado objcuadrado = new Cuadrado(float.Parse(txtLado.Text),0,0,0,0,0);
            MessageBox.Show(objcuadrado.imprimirResultado());
        }

        private void btnPerimetro_Click(object sender, EventArgs e)
        {
           
        }

        private void btnTriangulo_Click(object sender, EventArgs e)
        {
            Triangulo objtriangulo = new Triangulo(float.Parse(txtlado1.Text), float.Parse(txtlado2.Text), float.Parse(txtlado3.Text), 0, 0, float.Parse(txtbase.Text));
            MessageBox.Show(objtriangulo.imprimirResultado());
        }

        private void btnCirculo_Click(object sender, EventArgs e)
        {
            Circulo objcirculo = new Circulo(float.Parse(txtLado.Text), 0, 0, 0, 0, 0);
            MessageBox.Show(objcirculo.imprimirResultado());
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txtlado2_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnPerimetro_Click_1(object sender, EventArgs e)
        {

        }
    }
}
