﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    class Circulo: Operacion
    {
        public Circulo(float valor1, float valor2, float valor3, float area, float perimetro, float baset) : base(valor1, valor2, valor3, area, perimetro, baset)
        {

        }
        public override string imprimirResultado()
        {
            areaobt = Convert.ToSingle( 3.1416 *(valor1obt*valor1obt));
            perimetroobt = Convert.ToSingle((2 * 3.1416) * valor1obt);
            return "El area del circulo es:" + areaobt + "\n" + "El perimetro del circulo es:" + perimetroobt + "\n" + "";
            throw new NotImplementedException();
        }
    }
}
