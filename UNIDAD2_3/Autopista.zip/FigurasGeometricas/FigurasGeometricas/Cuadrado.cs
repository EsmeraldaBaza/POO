﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    class Cuadrado :Operacion
    {
        public Cuadrado(float valor1, float valor2, float valor3, float area, float perimetro, float baset) : base(valor1,valor2, valor3, area,perimetro, baset)
        {

        }
        public override string imprimirResultado()
        {
             areaobt = valor1obt * valor1obt;
            perimetroobt = 4 * valor1obt;
            return "El area del cuadrado es:" + areaobt + "\n" + "El perimetro del cuadrado es:" + perimetroobt + "\n" + "";
            throw new NotImplementedException();
        }
    }
}
