﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
     abstract class FigurasGeometricas
    {
        protected float valor1obt;
        protected float valor2obt;
        protected float valor3obt;
        protected float baseobt;
        protected float areaobt;
        protected float perimetroobt;

        public FigurasGeometricas(float valor1, float valor2, float valor3, float area, float perimetro, float baset) 
        {
            valor1obt = valor1;
            valor2obt = valor2;
            valor3obt = valor3;
            baseobt = baset;
            areaobt = area;
            perimetroobt = perimetro;
        }
        public abstract string imprimirResultado(); 


    }
}
