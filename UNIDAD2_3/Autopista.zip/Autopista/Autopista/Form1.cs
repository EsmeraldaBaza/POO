﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Autopista
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCantidad_Click(object sender, EventArgs e)
        {
            Vehiculo objVehiculo = new Vehiculo();
            int Tipo = cboTipo.SelectedIndex;
            int Cobro = objVehiculo.Cantidad(Tipo);
            MessageBox.Show("La cantidad a cobrar es: $" + Cobro + "");// Mensaje en pantalla
        }
    }
}
