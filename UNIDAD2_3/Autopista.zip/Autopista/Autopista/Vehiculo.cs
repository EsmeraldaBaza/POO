﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autopista
{
    class Vehiculo
    {
        public int Cantidad(int Precio)
        {
            int Cobro = 0;
            switch (Precio)
            {
                case 0:
                    Cobro = 50;
                    break;
                case 1:
                    Cobro = 112;
                    break;
                case 2:
                    Cobro = 170;
                    break;
                case 3:
                    Cobro = 250;
                    break;

            }
            return Cobro;
        }
    }
}
