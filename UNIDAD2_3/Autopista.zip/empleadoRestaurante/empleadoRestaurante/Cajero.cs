﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empleadoRestaurante
{
    class Cajero:Empleado
    {
        public Cajero(string nombreEmpleadoobt, DateTime fechanacimientoobt, int diastrabajadosobt, float sueldoobt) : base(nombreEmpleadoobt, fechanacimientoobt, diastrabajadosobt, sueldoobt)
        {

        }
        private int indexcaja;
        private double sueldocalculado;
        public int Indexcaja
        {
            set
            {
                indexcaja = value;
            }
            get
            {
                return indexcaja;
            }
        }
        public override string calcularsueldo()
        {
            if (indexcaja == 0)
            {
                sueldocalculado = sueldo * diastrabajados;
                return "El Mesero " + nombreEmpleado + " con fecha de nacimiento " + fechanacimiento + " \n" + "Su salario semanal fue " + sueldocalculado + "";
            }
            else 
            {
                sueldocalculado = (sueldo*diastrabajados) + ((sueldo*diastrabajados) * 0.03);
                return "El Mesero " + nombreEmpleado + " con fecha de nacimiento " + fechanacimiento + " \n" + "Su salario semanal fue " + sueldocalculado + "";
            }
            throw new NotImplementedException();
        }
    }
}
