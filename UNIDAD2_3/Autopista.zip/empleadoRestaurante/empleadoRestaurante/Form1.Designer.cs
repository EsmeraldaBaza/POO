﻿namespace empleadoRestaurante
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtPropinasM = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCalcularSueldo = new System.Windows.Forms.Button();
            this.txtSueldoMesero = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboDiasTrabajoM = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpFechaEmpleado = new System.Windows.Forms.DateTimePicker();
            this.txtNombreMesero = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSueldoSemanalCajero = new System.Windows.Forms.Button();
            this.cboCaja = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSueldoCajero = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cboDiasTrabajoCajero = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpFechaNCajero = new System.Windows.Forms.DateTimePicker();
            this.txtNombreCajero = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtPedidos = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cboZona = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPropinasRepartidor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSueldoSemanalRepartidor = new System.Windows.Forms.Button();
            this.txtSueldoRepartidor = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cboDiasTrabajoRepartidor = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpFechaNRepartidor = new System.Windows.Forms.DateTimePicker();
            this.txtNombreRepartidor = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(-3, 15);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1053, 524);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Maroon;
            this.tabPage1.Controls.Add(this.txtPropinasM);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.btnCalcularSueldo);
            this.tabPage1.Controls.Add(this.txtSueldoMesero);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.cboDiasTrabajoM);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dtpFechaEmpleado);
            this.tabPage1.Controls.Add(this.txtNombreMesero);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(1045, 495);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mesero";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // txtPropinasM
            // 
            this.txtPropinasM.Location = new System.Drawing.Point(196, 222);
            this.txtPropinasM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPropinasM.Name = "txtPropinasM";
            this.txtPropinasM.Size = new System.Drawing.Size(265, 22);
            this.txtPropinasM.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(120, 230);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Propinas:";
            // 
            // btnCalcularSueldo
            // 
            this.btnCalcularSueldo.Location = new System.Drawing.Point(553, 108);
            this.btnCalcularSueldo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCalcularSueldo.Name = "btnCalcularSueldo";
            this.btnCalcularSueldo.Size = new System.Drawing.Size(220, 49);
            this.btnCalcularSueldo.TabIndex = 8;
            this.btnCalcularSueldo.Text = "Calcular sueldo Semanal ";
            this.btnCalcularSueldo.UseVisualStyleBackColor = true;
            this.btnCalcularSueldo.Click += new System.EventHandler(this.btnCalcularSueldo_Click);
            // 
            // txtSueldoMesero
            // 
            this.txtSueldoMesero.Location = new System.Drawing.Point(196, 182);
            this.txtSueldoMesero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSueldoMesero.Name = "txtSueldoMesero";
            this.txtSueldoMesero.Size = new System.Drawing.Size(265, 22);
            this.txtSueldoMesero.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(91, 191);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Sueldo diario:";
            // 
            // cboDiasTrabajoM
            // 
            this.cboDiasTrabajoM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDiasTrabajoM.FormattingEnabled = true;
            this.cboDiasTrabajoM.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.cboDiasTrabajoM.Location = new System.Drawing.Point(196, 133);
            this.cboDiasTrabajoM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboDiasTrabajoM.Name = "cboDiasTrabajoM";
            this.cboDiasTrabajoM.Size = new System.Drawing.Size(265, 24);
            this.cboDiasTrabajoM.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 143);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Dias que trabajo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 94);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Fecha de Nacimiento:";
            // 
            // dtpFechaEmpleado
            // 
            this.dtpFechaEmpleado.Location = new System.Drawing.Point(196, 85);
            this.dtpFechaEmpleado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpFechaEmpleado.Name = "dtpFechaEmpleado";
            this.dtpFechaEmpleado.Size = new System.Drawing.Size(265, 22);
            this.dtpFechaEmpleado.TabIndex = 2;
            // 
            // txtNombreMesero
            // 
            this.txtNombreMesero.Location = new System.Drawing.Point(196, 39);
            this.txtNombreMesero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNombreMesero.Name = "txtNombreMesero";
            this.txtNombreMesero.Size = new System.Drawing.Size(265, 22);
            this.txtNombreMesero.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 43);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre del empleado:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnSueldoSemanalCajero);
            this.tabPage2.Controls.Add(this.cboCaja);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.txtSueldoCajero);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.cboDiasTrabajoCajero);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.dtpFechaNCajero);
            this.tabPage2.Controls.Add(this.txtNombreCajero);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(1045, 495);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cajero";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnSueldoSemanalCajero
            // 
            this.btnSueldoSemanalCajero.Location = new System.Drawing.Point(329, 289);
            this.btnSueldoSemanalCajero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSueldoSemanalCajero.Name = "btnSueldoSemanalCajero";
            this.btnSueldoSemanalCajero.Size = new System.Drawing.Size(220, 49);
            this.btnSueldoSemanalCajero.TabIndex = 29;
            this.btnSueldoSemanalCajero.Text = "Calcular sueldo Semanal ";
            this.btnSueldoSemanalCajero.UseVisualStyleBackColor = true;
            this.btnSueldoSemanalCajero.Click += new System.EventHandler(this.btnSueldoSemanalCajero_Click);
            // 
            // cboCaja
            // 
            this.cboCaja.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCaja.FormattingEnabled = true;
            this.cboCaja.Items.AddRange(new object[] {
            "Caja 1",
            "Caja 2"});
            this.cboCaja.Location = new System.Drawing.Point(189, 224);
            this.cboCaja.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboCaja.Name = "cboCaja";
            this.cboCaja.Size = new System.Drawing.Size(160, 24);
            this.cboCaja.TabIndex = 28;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(137, 234);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 17);
            this.label17.TabIndex = 27;
            this.label17.Text = "Caja:";
            // 
            // txtSueldoCajero
            // 
            this.txtSueldoCajero.Location = new System.Drawing.Point(189, 170);
            this.txtSueldoCajero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSueldoCajero.Name = "txtSueldoCajero";
            this.txtSueldoCajero.Size = new System.Drawing.Size(132, 22);
            this.txtSueldoCajero.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(84, 178);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 17);
            this.label13.TabIndex = 25;
            this.label13.Text = "Sueldo diario:";
            // 
            // cboDiasTrabajoCajero
            // 
            this.cboDiasTrabajoCajero.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDiasTrabajoCajero.FormattingEnabled = true;
            this.cboDiasTrabajoCajero.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.cboDiasTrabajoCajero.Location = new System.Drawing.Point(189, 121);
            this.cboDiasTrabajoCajero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboDiasTrabajoCajero.Name = "cboDiasTrabajoCajero";
            this.cboDiasTrabajoCajero.Size = new System.Drawing.Size(53, 24);
            this.cboDiasTrabajoCajero.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(63, 130);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 17);
            this.label14.TabIndex = 23;
            this.label14.Text = "Dias que trabajo:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(31, 81);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 17);
            this.label15.TabIndex = 22;
            this.label15.Text = "Fecha de Nacimiento:";
            // 
            // dtpFechaNCajero
            // 
            this.dtpFechaNCajero.Location = new System.Drawing.Point(189, 73);
            this.dtpFechaNCajero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpFechaNCajero.Name = "dtpFechaNCajero";
            this.dtpFechaNCajero.Size = new System.Drawing.Size(265, 22);
            this.dtpFechaNCajero.TabIndex = 21;
            // 
            // txtNombreCajero
            // 
            this.txtNombreCajero.Location = new System.Drawing.Point(189, 27);
            this.txtNombreCajero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNombreCajero.Name = "txtNombreCajero";
            this.txtNombreCajero.Size = new System.Drawing.Size(132, 22);
            this.txtNombreCajero.TabIndex = 20;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(31, 31);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(151, 17);
            this.label16.TabIndex = 19;
            this.label16.Text = "Nombre del empleado:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txtPedidos);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.cboZona);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.txtPropinasRepartidor);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.btnSueldoSemanalRepartidor);
            this.tabPage3.Controls.Add(this.txtSueldoRepartidor);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.cboDiasTrabajoRepartidor);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.dtpFechaNRepartidor);
            this.tabPage3.Controls.Add(this.txtNombreRepartidor);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1045, 495);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Repartidor";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtPedidos
            // 
            this.txtPedidos.Location = new System.Drawing.Point(532, 263);
            this.txtPedidos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPedidos.Name = "txtPedidos";
            this.txtPedidos.Size = new System.Drawing.Size(132, 22);
            this.txtPedidos.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(384, 270);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(140, 17);
            this.label12.TabIndex = 24;
            this.label12.Text = "Pedidos Entregados:";
            // 
            // cboZona
            // 
            this.cboZona.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboZona.FormattingEnabled = true;
            this.cboZona.Items.AddRange(new object[] {
            "Zona 1",
            "Zona 2"});
            this.cboZona.Location = new System.Drawing.Point(172, 266);
            this.cboZona.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboZona.Name = "cboZona";
            this.cboZona.Size = new System.Drawing.Size(160, 24);
            this.cboZona.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(69, 272);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 17);
            this.label11.TabIndex = 22;
            this.label11.Text = "ZonaTrabajo:";
            // 
            // txtPropinasRepartidor
            // 
            this.txtPropinasRepartidor.Location = new System.Drawing.Point(172, 213);
            this.txtPropinasRepartidor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPropinasRepartidor.Name = "txtPropinasRepartidor";
            this.txtPropinasRepartidor.Size = new System.Drawing.Size(132, 22);
            this.txtPropinasRepartidor.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(96, 222);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "Propinas:";
            // 
            // btnSueldoSemanalRepartidor
            // 
            this.btnSueldoSemanalRepartidor.Location = new System.Drawing.Point(219, 299);
            this.btnSueldoSemanalRepartidor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSueldoSemanalRepartidor.Name = "btnSueldoSemanalRepartidor";
            this.btnSueldoSemanalRepartidor.Size = new System.Drawing.Size(220, 49);
            this.btnSueldoSemanalRepartidor.TabIndex = 19;
            this.btnSueldoSemanalRepartidor.Text = "Calcular sueldo Semanal ";
            this.btnSueldoSemanalRepartidor.UseVisualStyleBackColor = true;
            this.btnSueldoSemanalRepartidor.Click += new System.EventHandler(this.btnSueldoSemanalRepartidor_Click);
            // 
            // txtSueldoRepartidor
            // 
            this.txtSueldoRepartidor.Location = new System.Drawing.Point(172, 174);
            this.txtSueldoRepartidor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSueldoRepartidor.Name = "txtSueldoRepartidor";
            this.txtSueldoRepartidor.Size = new System.Drawing.Size(132, 22);
            this.txtSueldoRepartidor.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(67, 182);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 17);
            this.label7.TabIndex = 17;
            this.label7.Text = "Sueldo diario:";
            // 
            // cboDiasTrabajoRepartidor
            // 
            this.cboDiasTrabajoRepartidor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDiasTrabajoRepartidor.FormattingEnabled = true;
            this.cboDiasTrabajoRepartidor.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.cboDiasTrabajoRepartidor.Location = new System.Drawing.Point(172, 124);
            this.cboDiasTrabajoRepartidor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboDiasTrabajoRepartidor.Name = "cboDiasTrabajoRepartidor";
            this.cboDiasTrabajoRepartidor.Size = new System.Drawing.Size(53, 24);
            this.cboDiasTrabajoRepartidor.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 134);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 17);
            this.label8.TabIndex = 15;
            this.label8.Text = "Dias que trabajo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 85);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 17);
            this.label9.TabIndex = 14;
            this.label9.Text = "Fecha de Nacimiento:";
            // 
            // dtpFechaNRepartidor
            // 
            this.dtpFechaNRepartidor.Location = new System.Drawing.Point(172, 76);
            this.dtpFechaNRepartidor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpFechaNRepartidor.Name = "dtpFechaNRepartidor";
            this.dtpFechaNRepartidor.Size = new System.Drawing.Size(265, 22);
            this.dtpFechaNRepartidor.TabIndex = 13;
            // 
            // txtNombreRepartidor
            // 
            this.txtNombreRepartidor.Location = new System.Drawing.Point(172, 31);
            this.txtNombreRepartidor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNombreRepartidor.Name = "txtNombreRepartidor";
            this.txtNombreRepartidor.Size = new System.Drawing.Size(132, 22);
            this.txtNombreRepartidor.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 34);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(151, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "Nombre del empleado:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 354);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnCalcularSueldo;
        private System.Windows.Forms.TextBox txtSueldoMesero;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboDiasTrabajoM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpFechaEmpleado;
        private System.Windows.Forms.TextBox txtNombreMesero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPropinasM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPedidos;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboZona;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPropinasRepartidor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSueldoSemanalRepartidor;
        private System.Windows.Forms.TextBox txtSueldoRepartidor;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboDiasTrabajoRepartidor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpFechaNRepartidor;
        private System.Windows.Forms.TextBox txtNombreRepartidor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSueldoSemanalCajero;
        private System.Windows.Forms.ComboBox cboCaja;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtSueldoCajero;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboDiasTrabajoCajero;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtpFechaNCajero;
        private System.Windows.Forms.TextBox txtNombreCajero;
        private System.Windows.Forms.Label label16;
    }
}

