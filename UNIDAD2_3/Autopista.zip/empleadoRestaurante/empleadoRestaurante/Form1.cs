﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace empleadoRestaurante
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cboCaja.SelectedIndex = 0;
            cboDiasTrabajoCajero.SelectedIndex = 0;
            cboDiasTrabajoM.SelectedIndex = 0;
            cboDiasTrabajoRepartidor.SelectedIndex = 0;
            cboZona.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

      

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcularSueldo_Click(object sender, EventArgs e)
        {
            Mesero objMesero = new Mesero(txtNombreMesero.Text,dtpFechaEmpleado.Value.Date,(cboDiasTrabajoM.SelectedIndex+1),float.Parse(txtSueldoMesero.Text));
            objMesero.Propina = float.Parse(txtPropinasM.Text);
            MessageBox.Show(objMesero.calcularsueldo());
        }

        private void btnSueldoSemanalRepartidor_Click(object sender, EventArgs e)
        {
            Repartidor objRepartidor = new Repartidor(txtNombreRepartidor.Text, dtpFechaNRepartidor.Value.Date, (cboDiasTrabajoRepartidor.SelectedIndex + 1), float.Parse(txtSueldoRepartidor.Text));
            objRepartidor.Indexzona = cboZona.SelectedIndex;
            objRepartidor.Propina = float.Parse(txtPropinasRepartidor.Text);
            objRepartidor.Abonoscobrados = int.Parse(txtPedidos.Text);
            MessageBox.Show(objRepartidor.calcularsueldo());
        }

        private void btnSueldoSemanalCajero_Click(object sender, EventArgs e)
        {
            Cajero objCajero = new Cajero(txtNombreCajero.Text, dtpFechaNCajero.Value.Date, (cboDiasTrabajoCajero.SelectedIndex + 1), float.Parse(txtSueldoCajero.Text));
            objCajero.Indexcaja = cboCaja.SelectedIndex;
            MessageBox.Show(objCajero.calcularsueldo());
        }
    }
}
