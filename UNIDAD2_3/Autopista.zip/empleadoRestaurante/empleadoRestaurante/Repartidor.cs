﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empleadoRestaurante
{
    class Repartidor:Empleado
    {
        public Repartidor(string nombreEmpleadoobt, DateTime fechanacimientoobt, int diastrabajadosobt, float sueldoobt) : base(nombreEmpleadoobt, fechanacimientoobt, diastrabajadosobt, sueldoobt)
        {

        }
        private float propina;
        private double sueldocalculado;
        private int indexzona;
        private int abonoscobrados;
        public float Propina
        {
            set
            {
                propina = value;
            }
            get
            {
                return propina;
            }
        }
        public int Indexzona
        {
        set {
                indexzona = value;
            }
            get 
            {
                return indexzona; 
            }
        }
        public int Abonoscobrados {
            set {
                abonoscobrados = value;
            }
            get {
                return abonoscobrados;
            }
        }
        public override string calcularsueldo()
        {
            int cantzona = 0;
            if (indexzona == 0)
            {
                cantzona = 5 * abonoscobrados;
                sueldocalculado = (sueldo * diastrabajados) + propina;
                sueldocalculado = sueldocalculado + cantzona;
                return "El Mesero " + nombreEmpleado + " con fecha de nacimiento " + fechanacimiento + " \n" + "Su salario semanal fue " + sueldocalculado + "";
            }
            else {
                cantzona = 2 * abonoscobrados;
                sueldocalculado = (sueldo * diastrabajados) + propina;
                sueldocalculado = sueldocalculado + cantzona;
                return "El Mesero " + nombreEmpleado + " con fecha de nacimiento " + fechanacimiento + " \n" + "Su salario semanal fue " + sueldocalculado + "";
            }
            throw new NotImplementedException();
        }
    }
}
