﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradosCentigrados
{
    class Temperatura
    {
        public double Grados(double Numero, double valor) //realizo mi metodo publico y coloco lo que realize en mis botones 
        {
            double G=0;
            if (valor == 0)
            {
                G = (Numero - 32) / 1.8;
            }
              else if (valor == 1)
                    {
                G = (Numero * 1.8) + 32;
                    }

            return G;


        }
    }
}
