﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GradosCentigrados
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNumero_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Numero = Convert.ToDouble(txtNumero.Text); //convertir texto a numero con punto decimal

            double valor = cmbGrados.SelectedIndex;

            Temperatura objTemperatura = new Temperatura(); //llamar a la clase y realizo un objeto
            lblResultado.Text= objTemperatura.Grados(Numero, valor).ToString();
           
          
        }
    }
}
