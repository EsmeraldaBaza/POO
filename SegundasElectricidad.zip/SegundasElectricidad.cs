﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Electricidad
{
    public partial class frmElectricidad : Form
    {

        public frmElectricidad()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)

        {
            object frmElectricidad = new frmElectricidad();



            int Kw = 0;
            int precio = 0;

            string txtKw;
            string cmbTipoContrato;

           


        }

           
            

        private void btnCalcular_Click(object sender, EventArgs e)
        {

           
        }

        private void txtKw_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Su tarifa de electricidad es: " + txtKw.Text);

        }
    }
         
       
        
    }

